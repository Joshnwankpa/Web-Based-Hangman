Every piece of code in my work is mine, the site i used for better understanding is below.
This is how my Hangman game would be played/Features;
- The basics of the game is to guess a provided word. 
- When the game is loaded a keyboard with all the alphabets would be shown below, this is what is to be used when trying to guess the word. 
- When using a computer the keyboard can also be used to type as opposed to using using the mouse and clicking on the screen keyboard.
- If the player is having trouble guessing the word the hint button right at the bottom would provide a clue when clicked.
- When given a word, and a correct letter from that word is selected, the dashes would update accordingly, but if the letter isn't contained in that word the hangman would get closer to getting hung and the wrong letter would be added to the wrong letter paragraph accordingly.

Some problems i faced;
- I had some problems enabling the keyboard but i was able to work it out.
- When the game is loaded and the word is either guessed rightly or wrongly with the computer's keyboard and the play again button is clicked, the computer's keyboard input isn't then noticed for a reason i don't know.
- Naming the variables were a  bit difficult for me.

What i would have added if i had more time;
- I would have added categories to the game to create variety for the user.
- I would have attempted to create a multiplayer option.
- I would have used canvas instead of creating images.

Sites used;
- https://developer.mozilla.org/en-US/docs/Web/API/Element/append
