export const wordList = [ 
    
    {
        word: 'rain',
        hint: 'Falls from the sky',
    },
    {
        word: 'sky',
        hint: 'It is above when we are outside',
    },
    {
         word: 'bunny',
         hint: 'Fluffy and long earred animal',
    },
    {
        word: 'laptop',
        hint: 'Portable desktop',
    },    
    {
        word: 'monitor',
        hint: 'Causes eye pains',
    },
    {
        word: 'cable',
        hint: 'The word is cavo in spanish',
    },
    {
        word: 'tuesday',
        hint: 'Day of the week',
    },
    {
        word: 'keyboard',
        hint: 'Used for typing',
    },
    {
        word: 'rainbow',
        hint: 'Appears in the sky',
    },
    {
         word: 'kennel',
         hint: 'Shelter for a dog',
    },
    {
        word: 'coffee',
        hint: 'Mostly drank in the morning',
    },    
    {
        word: 'elephant',
        hint: 'Characterized by their long trunk ',
    },
    {
        word: 'lion',
        hint: 'The word is cavo in spanish',
    },
    {
        word: 'monday',
        hint: 'Day of the week',
    },
];

