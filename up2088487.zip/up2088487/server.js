import express from 'express';
    console.log('hello');

const app = express();
app.use(express.static('client'));
 app.listen(8080);